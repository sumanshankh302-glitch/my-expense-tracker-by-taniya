const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const signup = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const user = await User.findOne({ email });
        if (user) {
            return res.status(409).json({
                message: "user is already exist, you can login",
                success: false
            });
        }
        const userModel = new User({
            name,
            email,
            password
        });
        userModel.password = await bcrypt.hash(password, 10);
        await userModel.save();
        console.log('Received data:', { name,email, password });
        res.status(201).json({
            message: "Signup successfully",
            success: true
        })}
    catch (err) {
        res.status(500).json({
            message: "Internal Server Error",
            success: false
        })}}
const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        console.log('Received data:', { email, password });
        const user1 = await User.findOne({ email });
        console.log('Found user:', user1);
        const errorMsg = "Auth failed email or password is wrong";
        if (!user1) {
            return res.status(401).json({
                message: errorMsg,
                success: false
            });
        }
        const isPassEqual = await bcrypt.compare(password, user1.password);
        if (!isPassEqual) {
            return res.status(401).json({
                message: errorMsg,
                success: false
            });
        }
        const jwtToken = jwt.sign(
            {
                email: user1.email,
                _id: user1._id
            }
            , process.env.JWT_SECRET, { expiresIn: '24h' }

        )
        console.log('Received data:', { email, password });
        return res.status(200).json({
            message: "Login Success",
            success: true,
            jwtToken,
            email,
            name: user1.name,
           
        })

    }
    catch (err) {
        console.error(err);
        
        res.status(500).json({
            message: "Internal Server Error",
            success: false
        })
    }
}
module.exports = {
    signup,
    login
}