import React from 'react'
function ExpenseDetails({incomeAmt,expenseAmt}) {
  return (
    <div>
        <div className='details'>
            Your Balance is {incomeAmt  -  expenseAmt}
        </div>
        <div className="amount-container">
          Income 
          <span className="IncomeAmt">
            {incomeAmt}
          </span>
          Expense 
          <span className="ExpenseAmt">
            {expenseAmt}
          </span>
        </div>
    </div>
  )}
export default ExpenseDetails