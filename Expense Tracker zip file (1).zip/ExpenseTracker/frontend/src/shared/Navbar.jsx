import React from 'react'

function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-container">
      <h2 className='navbar-title'>Expense Tracker</h2>
      </div>
    </nav>
  )
}

export default Navbar